package boton;

import javax.swing.*;
import java.awt.*;
import javax.imageio.ImageIO;
import java.io.IOException;

public class Boton extends JFrame {

    public Boton() {
        setTitle("3x3 Image Grid");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 3));

        // Adding buttons with images
        for (int i = 1; i <= 9; i++) {
            JButton button = new JButton();
            try {
                Image icon = ImageIO.read(getClass().getResource("/images/" + i + ".png"));
                button.addComponentListener(new java.awt.event.ComponentAdapter() {
                    public void componentResized(java.awt.event.ComponentEvent evt) {
                        int width = button.getWidth();
                        int height = button.getHeight();
                        if (width > 0 && height > 0) { // Ensure dimensions are valid
                            Image scaledImage = icon.getScaledInstance(width, height, Image.SCALE_SMOOTH);
                            button.setIcon(new ImageIcon(scaledImage));
                        }
                    }
                });
                // Set the initial icon size
                button.setIcon(new ImageIcon(icon.getScaledInstance(133, 133, Image.SCALE_SMOOTH)));
            } catch (IOException | IllegalArgumentException ex) {
                System.out.println("Error loading image: " + ex.getMessage());
            }

            add(button);
        }

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Boton::new);
    }
}
